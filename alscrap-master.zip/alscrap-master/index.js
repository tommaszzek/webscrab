const puppeter = require('puppeteer');
const cheerio =require('cheerio');
const fs = require('fs');
const { clearScreenDown } = require('readline');

const data='https://allegro.pl/kategoria/czesci-do-laptopow-77801?order=qd';
let broswer;
let decriptionpages;


async function scrapHomeIndex(url){
    try{
    
    const page =await broswer.newPage()
    await page.goto(url,{waitUntil:"networkidle2"});
    const html= await page.evaluate(()=>document.body.innerHTML);
    const $= await cheerio.load(html);
     

    const  homes= $("article").map((i,element)=>{
            let name=$(element).attr("aria-label");
            let link = $(element).find("a").attr("href");
            let cena = $(element).find('span._lf05o').attr("aria-label");
            let cena_d = $(element).find('div.mqu1_g3').text();
            let ilosc_z = $(element).find('span.msa3_z4').text();
            let spon = $(element).find('div._6a66d_qjI85').text();
            let ads;
            if(spon=="Oferta sponsorowana"){ ads="ADS"} else {ads='NO_ADS'}

            // regexp=/Dane firmy(?:(?!Dane|Konkat).)*Kontakt/gm
           let id=i
            
                    // let c=i+';'+';'+s+';'+name+';'+cena+';'+cena_d+';'+ilosc_z+';'+link;
            if(name!=undefined){
                return {id,ads,name,cena,cena_d,ilosc_z,link};
            }

    }).get();
   


 
    
    return homes;
     
    }catch(err){
        console.log(err);
    }
    
}

async function getAdress(link,page){
    try{
       
        await page.goto(link,{waitUntil:"networkidle2"});
        

    }catch(err){
        console.log(err);
    }

}

  async function pagePagines(){
    broswer= await puppeter.launch({headless:false});
    decriptionpages=await broswer.newPage();
    const dane= await scrapHomeIndex(data)
    for(i=0;i<dane.length;i++){
        await getAdress(dane[i].link,decriptionpages)

    }
        // console.log(dane);

     

           


}
pagePagines();